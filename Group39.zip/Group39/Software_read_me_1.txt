Recommend using school computer labs’ computer.
--------------------------------------------------------------------------------------------------------------------
1. Go to "https://unity.com or https://unity.com/products/unity-educator" to create a Unity personal or educator account
   (just choose one of them, the educator account has more functions than the personal account).
--------------------------------------------------------------------------------------------------------------------
2. Please use "https://public-cdn.cloud.unity3d.com/hub/prod/UnityHubSetup.exe" to download and install Unity Hub.

After clicking https://unity.com/releases/editor/whats-new/2022.3.2, the screen below will be shown.

If you have already installed Unity Hub, Please click “Install this version with Unity Hub”. 
--------------------------------------------------------------------------------------------------------------------
3. After finishing installing Unity Editor 2022.3.2f, please download the project to Unity Hub.
--------------------------------------------------------------------------------------------------------------------
4. After opening Unity Hub, please click the Add button to add the project to Unity Hub and open it. 
--------------------------------------------------------------------------------------------------------------------




This app is designed for using in computer.
--------------------------------------------------------------------------------------------------------------------
1. Go into folder named "Build".
--------------------------------------------------------------------------------------------------------------------
2. Double click "Gounp39.exe", you can see that the app will be opened.
--------------------------------------------------------------------------------------------------------------------
3. Login to the School record system by input the userID and password in the input boxes and press the "login" button.
	
	Try: 1.input UserID: "132001" and Password: "12345678" into relevant input box
	     2. Click the "login" button
	     		
   You can see different between each user result by using differernt userID and password to login.
   After login you see your name below Main menu and there are four butten will show called "UserProfile", 
   "Course", "Result", "TimeTable" respectively.
---------------------------------------------------------------------------------------------------------------------
4. UserProfile, Click the "UserProfile" button. You will go into the "UserProfile" page which shows all the information 
   of you. 

	Function: Change your information by input the new information into the input box and press "Edit" button.

	Try: 1. Click the "UserProfile" button
	     2. Clear the input box and input "Jeff"
	     3. Click "Edit" button
	     4.	Click home button
	     5.	"Welcome back, Jeff" will be show below Main menu  

       *Home button, a house icon at up left corner, for going back to the main menu.  
---------------------------------------------------------------------------------------------------------------------
5. Course, Click "Course" button. You will go into "Course" page which show all the course you are studying.  
   
	Function: Click on diffenent course id to see more detailn course about that course.

 	Try:  1. Click the "Course" button 
	      2. Click "C101"
	      3. "C101" information are showing on the screen
	      4. Click the "home" button

	*Home button, a house icon at up left corner, for going back to the main menu.
---------------------------------------------------------------------------------------------------------------------
6. Result, Click "Result" button. You will go into "Result Sheet" page which show all the score of the course you are 
   studying. 

	Try: 1. Click the "Result" button 
	     2. The score of the course you are studying are showing on the screen
	     3. Click the "home" button

	*Home button, a house icon at up left corner, for going back to the main menu.
---------------------------------------------------------------------------------------------------------------------
7. TimeTable, Click "TimeTable" button. You will go into "TimeTable" page which show all the study time of the course 
   you are studying.

	try: 1. Click the "TimeTable" button 
	     2. The study time of the course you are studying are showing on the screen
	     3. Click the "home" button

	*Home button, a house icon at up left corner, for going back to the main menu.
---------------------------------------------------------------------------------------------------------------------
